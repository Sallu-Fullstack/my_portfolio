# my_portfolio.github.io
I'm Mohammed Salman, Striving to become a Passionate FullStack Developer. You can visit my Live Portfolio 👉: https://sallu-fullstack.github.io/my_portfolio.github.io/ 

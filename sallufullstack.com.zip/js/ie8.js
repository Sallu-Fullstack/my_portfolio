jQuery(document).ready(function(){
	"use strict";
    jQuery('body').html('<div class="ie8"><span>Hi! Please, use the latest version of the browser in order to visit current page</span></div>');
});